# Belajar Kubernetes

Ini adalah source code untuk materi screencast :

https://www.youtube.com/playlist?list=PL-CtdCApEFH8XrWyQAyRd6d_CKwxD8Ime

Anda bisa melihat slide materinya disini :

https://docs.google.com/presentation/d/1NJQqJd89k1od_o9Kz-79IQ_CQYDCJKWunCtpgkHQLi4/edit?usp=sharing


