<html>
	<head>
		<title>Halaman Login</title>
	</head>	
<body  bgcolor="lightsalmon">
<center><h1><b style = "color : black">LOGIN</b></h1></center>
<center>
<form action="" method="POST">
<table border = "0">
<tr>
	<td>Username </td>
	<td>:</td>
	<td><input type="text" name = "uname" value = ""></td>
</tr>
<tr>
	<td>Password </td>
	<td>:</td>
	<td><input type="password" name = "pass" value = ""></td>
</tr> 
<tr>
	<td></td>
	<td></td>
	<td><input type="submit" name = "login" value="LOGIN"> </td>
</tr>
</table>
</form>
</center>
</body>
</html>