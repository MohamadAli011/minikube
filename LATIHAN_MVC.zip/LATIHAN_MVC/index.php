<?php  
include_once 'controller/controller.php';
$controller = new Controller();
$controller->login();
?>